# florante-at-laura-visual-novel

An Android Visual Novel made using [Ren'Py](https://www.renpy.org/). It aims to gamify the learning experience of Florante at Laura to make it easier for students (Grade 8 specifically) to understand the Philippine Epic.
## Download

[v0.5-alpha](https://github.com/iamjethrooo/florante-at-laura-visual-novel/releases/download/v0.5-alpha/FaL-v0.5-alpha.apk)
- Working prototype up to chapter 10
- Added chapter selection screen
- Disabled settings screen (for now)
- Added backgrounds and character pictures (Florante and Aladin)

[v0.1-alpha](https://github.com/iamjethrooo/florante-at-laura-visual-novel/releases/download/v0.1-alpha/FaL-v0.1-alpha.apk)
- First build

## License

[MIT](https://choosealicense.com/licenses/mit/)
